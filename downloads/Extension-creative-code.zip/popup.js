// ===== خلفية متحركة =====
(() => {
  const c = document.getElementById('bg');
  const ctx = c.getContext('2d');
  let w,h;
  function resize(){
    w=c.width=window.innerWidth; h=c.height=window.innerHeight;
  }
  resize(); window.onresize=resize;

  const pts = Array.from({length:60},()=>({
    x:Math.random()*w, y:Math.random()*h,
    vx:(Math.random()-.5)*0.6, vy:(Math.random()-.5)*0.6
  }));

  function draw(){
    ctx.clearRect(0,0,w,h);
    for(let p of pts){
      p.x+=p.vx; p.y+=p.vy;
      if(p.x<0||p.x>w) p.vx*=-1;
      if(p.y<0||p.y>h) p.vy*=-1;
      ctx.fillStyle="rgba(255,255,255,.7)";
      ctx.beginPath(); ctx.arc(p.x,p.y,2,0,Math.PI*2); ctx.fill();
    }
    for(let i=0;i<pts.length;i++){
      for(let j=i+1;j<pts.length;j++){
        const a=pts[i],b=pts[j];
        const dx=a.x-b.x,dy=a.y-b.y;
        const dist=Math.hypot(dx,dy);
        if(dist<100){
          ctx.strokeStyle="rgba(255,62,200,"+(1-dist/100)+")";
          ctx.beginPath(); ctx.moveTo(a.x,a.y); ctx.lineTo(b.x,b.y); ctx.stroke();
        }
      }
    }
    requestAnimationFrame(draw);
  }
  draw();
})();

// ===== كورسات + أيقونات =====
const COURSE_LIST = [
  { title:"HTML – MDN", tag:"HTML", url:"https://developer.mozilla.org/en-US/docs/Web/HTML", img:"https://cdn-icons-png.flaticon.com/512/732/732212.png" },
  { title:"CSS – W3Schools", tag:"CSS", url:"https://www.w3schools.com/css/", img:"https://cdn-icons-png.flaticon.com/512/732/732190.png" },
  { title:"JavaScript – freeCodeCamp", tag:"JavaScript", url:"https://www.freecodecamp.org/learn/javascript-algorithms-and-data-structures/", img:"https://cdn-icons-png.flaticon.com/512/5968/5968292.png" },
  { title:"React – Docs", tag:"React", url:"https://react.dev/learn", img:"https://cdn-icons-png.flaticon.com/512/3334/3334886.png" },
  { title:"Node.js – Docs", tag:"Node.js", url:"https://nodejs.org/en/learn", img:"https://cdn-icons-png.flaticon.com/512/919/919825.png" },
  { title:"TypeScript – Handbook", tag:"TypeScript", url:"https://www.typescriptlang.org/docs/handbook/intro.html", img:"https://cdn-icons-png.flaticon.com/512/5968/5968381.png" },
  { title:"Python – freeCodeCamp", tag:"Python", url:"https://www.freecodecamp.org/learn/scientific-computing-with-python/", img:"https://cdn-icons-png.flaticon.com/512/5968/5968350.png" },
  { title:"Django – Tutorial", tag:"Django", url:"https://docs.djangoproject.com/en/stable/intro/tutorial01/", img:"https://static.djangoproject.com/img/logos/django-logo-negative.png" },
  { title:"Flask – Docs", tag:"Flask", url:"https://flask.palletsprojects.com/en/latest/tutorial/", img:"https://icon.icepanel.io/Technology/png-shadow-512/Flask.png" },
  { title:"PHP – W3Schools", tag:"PHP", url:"https://www.w3schools.com/php/", img:"https://cdn-icons-png.flaticon.com/512/5968/5968332.png" },
  { title:"Laravel – Docs", tag:"Laravel", url:"https://laravel.com/docs", img:"https://cdn-icons-png.flaticon.com/512/919/919830.png" },
  { title:"Java – Oracle", tag:"Java", url:"https://docs.oracle.com/javase/tutorial/", img:"https://cdn-icons-png.flaticon.com/512/226/226777.png" },
  { title:"Spring – Guides", tag:"Spring", url:"https://spring.io/guides", img:"https://icon.icepanel.io/Technology/svg/Spring.svg" },
  { title:"C++ – LearnCpp", tag:"C++", url:"https://www.learncpp.com/", img:"https://cdn-icons-png.flaticon.com/512/6132/6132222.png" },
  { title:"C – GFG", tag:"C", url:"https://www.geeksforgeeks.org/c-programming-language/", img:"https://cdn-icons-png.flaticon.com/512/3665/3665923.png" },
  { title:"Rust – The Book", tag:"Rust", url:"https://doc.rust-lang.org/book/", img:"https://www.rust-lang.org/static/images/rust-logo-blk.svg" },
  { title:"SQL – SQLBolt", tag:"SQL", url:"https://sqlbolt.com/", img:"https://cdn-icons-png.flaticon.com/512/4248/4248443.png" },
  { title:"Git – Atlassian", tag:"Git", url:"https://www.atlassian.com/git/tutorials", img:"https://cdn-icons-png.flaticon.com/512/2111/2111288.png" },
  { title:"CS50 – Harvard", tag:"CS", url:"https://cs50.harvard.edu/x/", img:"https://upload.wikimedia.org/wikipedia/commons/2/25/Harvard_University_shield.png" },
  { title:"The Odin Project", tag:"Full Stack", url:"https://www.theodinproject.com/paths", img:"https://www.josharcher.uk/static/img/2015/05/odin.gif" }
];

const grid=document.getElementById("courses");

function render(list){
  grid.innerHTML='';
  list.forEach(item=>{
    const card=document.createElement('div');
    card.className='course';
    card.innerHTML=`
      <img src="${item.img}" class="course-img" alt="${item.tag}">
      <h3>${item.title}</h3>
      <p>#${item.tag}</p>
      <button class="open">Open</button>
    `;
    card.querySelector(".open").addEventListener("click",()=>chrome.tabs.create({url:item.url}));
    grid.appendChild(card);
  });
}
render(COURSE_LIST);

document.getElementById("search").addEventListener("input",e=>{
  const q=e.target.value.toLowerCase();
  render(COURSE_LIST.filter(c=>c.title.toLowerCase().includes(q)||c.tag.toLowerCase().includes(q)));
});

